# 1ME etusivu

Staattinen yhden sivun etusivu Plesk-julkaisua varten.

## Tiedostot

- `index.html` – sivun rakenne ja sisältö
- `styles.css` – ulkoasu ja responsiivisuus
- `script.js` – vuosiluvun automaattinen päivitys
- `.htaccess` – Apache/Plesk-perusasetukset

## Julkaisu Pleskissä Gitillä

1. Luo GitHubiin, GitLabiin tai Bitbucketiin uusi repository.
2. Lisää nämä tiedostot repositoryn juureen.
3. Pleskissä valitse domainin Git-asetuksissa **Remote repository**.
4. Lisää repositoryn HTTPS- tai SSH-osoite.
5. Aseta deployment-poluksi yleensä domainin `httpdocs`-hakemisto.
6. Deployment mode: automaattinen julkaisu, jos haluat että Plesk päivittää sivun aina kun repository päivittyy.

Sivu ei vaadi Nodea, build-komentoja tai tietokantaa.
